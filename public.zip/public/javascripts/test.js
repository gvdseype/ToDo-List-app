let string = '02/2015'
let newString = string.slice(0, 7)
console.log(newString)